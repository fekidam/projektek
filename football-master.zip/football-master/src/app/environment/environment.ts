export const firebaseConfig = {
    apiKey: "AIzaSyB6N8Uufrjy63HwQb8rzmjhERBn-U59DDA",
    authDomain: "foci-c8bef.firebaseapp.com",
    projectId: "foci-c8bef",
    storageBucket: "foci-c8bef.appspot.com",
    messagingSenderId: "482788246258",
    appId: "1:482788246258:web:5e86643d5e3a2b9eeb866b",
    measurementId: "G-VE6FXJZT2C"
};