export interface Result {
    homeName: string;
    homeGoals: number;
    awayName: string;
    awayGoals: number;
    homeImage: string;
    awayImage: string;
    id?: string;
}